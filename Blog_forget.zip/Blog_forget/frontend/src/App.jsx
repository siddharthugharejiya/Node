import Register from './Componets/Register'
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';

import MainRoute from './Route/MainRoute';
function App() {
  // const [count, setCount] = useState(0)


  return (
    <>
   {/* <Register/> */}
   <MainRoute/>
   
    
    </>
  
  )
}

export default App
