const bcrypt = require('bcrypt')
const UserModel = require('../Model/UserModel')
const jwt = require('jsonwebtoken')
const cookie = require('cookie-parser')
const register = async (req, res) => {
    const { username, email, password } = req.body
    //    let data = await UserModel.find({email : email})
    //    if(data)
    //    {
    //     console.log("User Already register")
    //   }
     await bcrypt.hash(password, 10, async (err, hash) => {
        if (err) {
            console.log(err)
        }
        if (hash) {
            await UserModel.create({
                username,
                email,
                password: hash
            })
            res.send({ msg: "Register successfully" })

        }
    })
}
const Login = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await UserModel.findOne({ email });
        console.log(user);
        

        if (!user) {
            return res.status(400).send({ message: "Invalid Email" });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).send({ message: "Invalid Password" });
        }

        const token = jwt.sign({ email: user.email, userid: user._id }, "your_secret_key");
        // localStorage.setItem(token)
        
        console.log(token);
        
       cookie("authToken", token, { httpOnly: true })
        res.cookie("authToken", token, { httpOnly: true });


        return res.status(200).send({ message: "Login Successful" });

    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: "Internal Server Error" });
    }
};







module.exports = { register , Login}