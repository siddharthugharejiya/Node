import './App.css'
import MainRoute from './Componets/MainRoute'
import 'bootstrap/dist/css/bootstrap.min.css';
import Nav_Main from './Componets/Nav_Main';

function App() {
  return (
    <>
      <Nav_Main />
      <MainRoute />
    </>
  );
}

export default App;
