import React, { useEffect } from 'react'

function Own() {
  useEffect(()=>{

    // fetch("http://localhost:9595/blog/")
  },[])

  return (
   <></>
  )
}

export default Own