 const BlogModel = require("../Model/BlogModel");
 const mongoose = require('mongoose')

const blog = async (req, res) => {
 
    try {
        let data = await BlogModel.find()
        console.log(data.userId);
        
        // console.log(data); 
        res.send({msg : `this is all blog data is`, data : data})
   
    } catch (error) {
        console.error("Error fetching blogs:", error);
      
    }
};


const blog_post = async (req, res) => {
  const { title, image, description, userId } = req.body;

  try {
    const newBlog = await BlogModel.create({
      title,
      image,
      description,
      userId: userId, // Ensure the key matches the field in the schema
    });

    res.status(201).send({
      msg: "Blog added successfully",
      blog: newBlog,
    });
  } catch (error) {
    console.error("Error adding blog:", error);
    res.status(500).send({ msg: "Failed to add blog", error: error.message });
  }
};


const Own_blog = async (req, res) => {
  const { userId } = req.body;

  try {
    if (!userId) {
      return res.status(400).send({ msg: "User ID is required" });
    }

    const blogs = await BlogModel.find({ userID: userId }).populate(
      "userID",
      "username email"
    );

    res.send({ msg: "User blogs fetched successfully", blogs });
  } catch (error) {
    console.error("Error fetching user blogs:", error);
    res.status(500).send({ msg: "Failed to fetch user blogs", error: error.message });
  }
};
const singleBlog = async (req, res) => {
  try {
    const data = await BlogModel.findById(req.params.id);

    if (!data) {
      return res.status(404).send({ msg: "Blog not found" });
    }

    res.send({ msg: "Blog fetched successfully", data });
  } catch (error) {
    console.error("Error fetching blog:", error);
    res.status(500).send({ msg: "Failed to fetch blog", error: error.message });
  }
};  


module.exports = { blog, blog_post ,Own_blog ,singleBlog};
