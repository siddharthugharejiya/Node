import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import Signup from './Components/Signup'
import './App.css'
import Login from './Components/Login'
import R from './Router/R'

function App() {
  // const [count, setCount] = useState(0)

  return (
  <>
   <R></R>
  {/* <Signup/> */}
  {/* <Login/> */}

  </>
  )
}

export default App
