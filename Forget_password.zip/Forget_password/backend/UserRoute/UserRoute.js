const express = require('express')
const { signup, login, Forget } = require('../Controller/UserController')
const UserRoute = express()
UserRoute.post("/",signup)
UserRoute.post("/login",login)
UserRoute.post("/forget",Forget)
module.exports = UserRoute